<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://abdulwahab.ml
 * @since             1.0.0
 * @package           Wp_Discussion
 *
 * @wordpress-plugin
 * Plugin Name:       Wp Discussion
 * Plugin URI:        http://abdulwahab.ml/wc-checkout-redirect
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Abdul Wahab
 * Author URI:        http://abdulwahab.ml
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wp-discussion
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WP_DISCUSSION_VERSION', '1.0.0' );
define('AW_PLUGIN_PATH',plugin_dir_path(__FILE__));
define('AW_PLUGIN_URL',plugin_dir_url( __FILE__ ));

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wp-discussion-activator.php
 */
function activate_wp_discussion() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-discussion-activator.php';
	Wp_Discussion_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wp-discussion-deactivator.php
 */
function deactivate_wp_discussion() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-discussion-deactivator.php';
	Wp_Discussion_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wp_discussion' );
register_deactivation_hook( __FILE__, 'deactivate_wp_discussion' );


define( 'MY_ACF_PATH', plugin_dir_path( __FILE__ ) . 'includes/acf/' );
define( 'MY_ACF_URL', plugin_dir_url( __FILE__ ) . 'includes/acf/' );

// Include the ACF plugin.
include_once( MY_ACF_PATH . 'acf.php' );



// Customize the url setting to fix incorrect asset URLs.
add_filter('acf/settings/url', 'my_acf_settings_url');
function my_acf_settings_url( $url ) {
    return MY_ACF_URL;
}

// (Optional) Hide the ACF admin menu item.
// add_filter('acf/settings/show_admin', 'my_acf_settings_show_admin');
// function my_acf_settings_show_admin( $show_admin ) {
//     return false;
// }

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wp-discussion.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wp_discussion() {

	$plugin = new Wp_Discussion();
	$plugin->run();

}
run_wp_discussion();