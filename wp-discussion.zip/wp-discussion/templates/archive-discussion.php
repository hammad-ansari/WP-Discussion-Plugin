<?php
/*
* To override this file place this file in your theme folder under wp-discussion folder
*/

get_header();

global $wpdb;
    $page = (get_query_var('paged')) ? get_query_var('paged') : 1;
$args = ['post_type' => 'discussion','posts_per_page' => 20,'paged' => $page];

if(isset($_POST['aw_submit'])){
    

        //$args['meta_query'] = ['relation' => 'AND',['meta_key' => 'law_code','meta_value' => $_POST['aw_search'],'compare' => 'LIKE']];
       
         
        switch($_POST['s_select']){
            
           
            
            case '1':
                
                $args = ['post_type' => 'discussion','posts_per_page' => -1, 
        
       'meta_query' => array(
           'relation' => 'OR',
        array(
            'key'     => 'file_no',
            'value'   => $_POST['aw_search'],
            'compare' => 'LIKE',
        ),
        array(
            'key'     => 'law_code',
            'value'   => $_POST['aw_search'],
            'compare' => 'LIKE',
        ),
        array(
            'key'     => 'question',
            'value'   => $_POST['aw_search'],
            'compare' => 'LIKE',
        ),
        array(
            'key'     => 'answer',
            'value'   => $_POST['aw_search'],
            'compare' => 'LIKE',
        ),
        array(
            'key'     => 'folder_no',
            'value'   => $_POST['aw_search'],
            'compare' => 'LIKE',
        ),
        
    )];
    
    $posts = [0];
    
     $query = new WP_Query($args);
     
     if($query->have_posts()){
         
         while($query->have_posts()){
             $query->the_post();
             
             $posts[] = get_the_ID();
             
         }
         
     }
     
     wp_reset_postdata();
    
     $args = ['post_type' => 'discussion','posts_per_page' => -1, 's' => $_POST['aw_search']];
     
     
     $query = new WP_Query($args);
     
     if($query->have_posts()){
         
         while($query->have_posts()){
             $query->the_post();
             
             $posts[] = get_the_ID();
             
         }
         
     }
     
     wp_reset_postdata();
     
     
     $args = ['post_type' => 'discussion','posts_per_page' => -1, 'post__in' => $posts];
     
                
                
                
                break;
            
            case '2':
                
               $args = ['post_type' => 'discussion','posts_per_page' => -1,'paged' => $page, 
        
       'meta_query' => array(
           'relation' => 'OR',
        array(
            'key'     => 'file_no',
            'value'   => $_POST['aw_search'],
            'compare' => 'LIKE',
        ),
       
        
    )];
                
                break;
                
                case '3':
                    
                    $args = ['post_type' => 'discussion','posts_per_page' => -1,'paged' => $page, 
        
       'meta_query' => array(
           'relation' => 'OR',
       
        array(
            'key'     => 'document_date',
            'value'   => $_POST['aw_search'],
            'compare' => 'LIKE',
        )
        
    )];
                break;
                
                case '4':
                     $args['s'] = $_POST['aw_search'];
                break;
                
                case '5':
                   $args = ['post_type' => 'discussion','posts_per_page' => -1,'paged' => $page, 
        
       'meta_query' => array(
           'relation' => 'OR',
       
        array(
            'key'     => 'law_code',
            'value'   => $_POST['aw_search'],
            'compare' => 'LIKE',
        )
        
    )];
                break;
                
                case '6':
                    $args = ['post_type' => 'discussion','posts_per_page' => -1,'paged' => $page, 
        
       'meta_query' => array(
           'relation' => 'OR',
       
        array(
            'key'     => 'question',
            'value'   => $_POST['aw_search'],
            'compare' => 'LIKE',
        ),
        
    )];
                break;
                
                case '7':
                   
                   $args = ['post_type' => 'discussion','posts_per_page' => -1,'paged' => $page, 
        
       'meta_query' => array(
           'relation' => 'OR',
       
        array(
            'key'     => 'answer',
            'value'   => $_POST['aw_search'],
            'compare' => 'LIKE',
        )
        
    )];
                break;
            
            case '8':
                $args = ['post_type' => 'discussion','posts_per_page' => -1,'paged' => $page,
        
       'meta_query' => array(
           'relation' => 'OR',
        array(
            'key'     => 'folder_no',
            'value'   => $_POST['aw_search'],
            'compare' => 'LIKE',
        ),
        
    )];
                break;
                

        }


}


$query = new WP_Query($args);

// var_dump($query);

?>

 <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">


<section id="top-filters">
	<div class="aw-container container" >
		<h1>
			ข้อหารือภาษีอากร
		</h1>
		<form action="<?= site_url('/discussion')?>" class="filter-form" method="post">
			<div class="aw-form-group1">
				<select name="s_select" class="aw-field">
				     <option <?= (isset($_POST['s_select']) && $_POST['s_select'] == '1')? 'selected': ''; ?> value="1">ค้นหาทั้งหมด</option>
				     
				     <option <?= (isset($_POST['s_select']) && $_POST['s_select'] == '2')? 'selected': ''; ?> value="2">เลขที่หนังสือ</option>
				       <option <?= (isset($_POST['s_select']) && $_POST['s_select'] == '8')? 'selected': ''; ?> value="8">เลขตู้</option>
                           
				  <option <?= (isset($_POST['s_select']) && $_POST['s_select'] == '4')? 'selected': ''; ?> value="4">เรื่อง
				    </option>
                               
                                ion>
                                <!--<option value="3">วันที่</option>-->
                                <!-->-->
                                <option <?= (isset($_POST['s_select']) && $_POST['s_select'] == '5')? 'selected': ''; ?> value="5">ข้อกฎหมาย</option>
                                <option <?= (isset($_POST['s_select']) && $_POST['s_select'] == '6')? 'selected': ''; ?> value="6">ข้อหารือ</option>
                                <option <?= (isset($_POST['s_select']) && $_POST['s_select'] == '7')? 'selected': ''; ?> value="7">แนววินิจฉัย</option>
                               </select>
			</div>

			<div class="aw-form-group2">
				<input type="text" style="width:90%;display:inline-block;" value="<?= isset($_POST['aw_search'])?$_POST['aw_search']:'';?>" name="aw_search" class="aw-field" placeholder="กรุณาใส่คำค้นหา">
				<input type="submit" style="width:9%;display:inline-block;" name="aw_submit" value="ค้นหา"/>
				<!--<div class="adv-search">-->
				<!--<label>	Sort By : </label>-->
				<!--	<label><input type="radio" name="sort" checked> Latest First</label>-->
				<!--	<label><input type="radio" name="sort"> Latest Later</label>-->
				<!--</div>-->
			</div>
		</form>
	</div>	
</section>

<section>
	<div class=" container"  >
		<div class="aw-post-loop">
			<h2>ผลการค้นหา</h2>


            <?php
            
            $aw_posts = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}posts WHERE post_type='discussion' AND post_status='publish'",ARRAY_A);
            
       
            if($query->have_posts()){
                
                ?>
                
                    <p>ค้นพบ <?= $query->post_count;?> รายการ จากข้อหารือทั้งหมด <?= count($aw_posts);?> รายการ</p>
		        	<hr>
                
                <?php
                
                while($query->have_posts()){
                    $query->the_post();
                    $post_id = get_the_ID();
            ?>

        			<div class="aw-post">
        				<div class="aw-content">
        					<p>
        					    <b>เรื่อง:</b> 
        					    <a href="<?= get_permalink($post_id);?>">
        					        <?= get_the_title();?>
        					    </a> 
        					<br>
        					<b>ข้อกฎหมาย:</b>  <?= get_field('law_code');?>
        					<br>
        					<b>เลขที่หนังสือ:</b> <?= get_field('file_no');?>
        					
        					</p>
        				</div>
        
        				<div class="aw-date" style="text-align:right;">
        					<span><?= get_field('document_date',$post_id)?></span>
        				</div>
        			</div><hr>


			<?php } ?>
		<div class="paginations">
			<?php			
			$big = 999999999;
 echo paginate_links( array(
    'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
    'format' => '?paged=%#%',
    'current' => max( 1, get_query_var('paged') ),
    'total' => $query->max_num_pages
) );





			?>
			</div>	
			<?php }else{ ?>
			
			<p>ไม่พบข้อหารือที่เกี่ยวข้อง</p>
			<hr>
			
			<?php } wp_reset_postdata(); ?>

		</div>
	</div>
</section>
<style>
	.page-numbers{
	color: #888;
    font-size: 16px;
    padding: 10px;		
	}
	.page-numbers:hover{
		color: #e21111;
	}
	.paginations{
		    margin: 30px 0 50px 0;
    text-align: center;
	}
	.aw-form-group2>input[type=submit]{white-space:nowrap;}
	.aw-content>p{line-height:25px}
	
		@media only screen and (max-width: 768px) {
		.aw-form-group2>input[type=submit]{width:15% !important}	
		.aw-form-group2>.aw-field{ width:84% !important; margin-bottom:15px;}
		
	}
	
	@media only screen and (max-width: 600px) {
		.aw-form-group2>input[type=submit]{width:100% !important}	
		.aw-form-group2>.aw-field{ width:100% !important; margin-bottom:15px;}
		.adv-search{text-align:left}
	}
	
	@media screen and (max-width: 900px) and (min-width: 600px) {
  .aw-form-group2>input[type=submit]{width:15% !important}	
		.aw-form-group2>.aw-field{ width:84% !important; margin-bottom:15px;}
}
	
</style>

<?php

get_footer();

?>