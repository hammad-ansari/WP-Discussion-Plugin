<?php

wp_enqueue_style('single-page','https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
//AW_PLUGIN_URL . 
get_header();

$views = get_post_meta(get_the_ID(),'aw_views',true);
$views = $views?$views+1:1;

update_post_meta(get_the_ID(),'aw_views',$views);

?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<style>
	.social-icon-col{top:155px}
	.heading,.heading-text{margin-top:40px !important}
.heading-text h1 {
    font-weight: 600;
    padding-bottom: 25px;
    line-height: 1.5;
    font-size: 2.5rem;
    text-align: left;
    font-family: 'kanit', sans-serif !important;
}
	.heading>.number {
    font-weight: 600;
    
    text-align: left;
    font-family: 'kanit', sans-serif !important;
}
	.fb-icons i{line-height:38px}
	.twitter-icons i,.linkedin-icons i{line-height:40px;}
	p{color:#333 !important;}
	.date>p{color:#888 !important}
	.btn-fb{background:#143177 !important;color:#fff !important}
	.btn-fb:active, .btn-fb:link{padding:0 110px !important;background:#143177 !important;color:#fff !important}
	.close>i,.open>i{    line-height: 45px;}
	
		@media only screen and (max-width: 600px) {
			.date{text-align:left !important;}
			.col-1{display:none !important}
			.social-icon-col>.heading{margin-left:-10px}
			 .btn-fb:link {
    padding: 0 30px !important;
}
			.heading-text h1{font-size:22px;}
			.container{width:90%;}
	}
	
	@media only screen and (max-width:990px) {
		
			.social-links{margin-left:-20px}
		.heading-text h1{font-size:30px;}
	}
	
	
	@media only screen and (max-width:1024px) and (min-width:990px) {
		
		.social-links{margin-left:-10px} }
</style>
    <div class="container">
        <div class="row">
            <div class="col-1">
                <div class="social-icon-col">
                    <div class="heading">
                        <div class="number">
                            <h1><?= $views?></h1>
                        </div>
                        <div class="views">
                            <h1>Views</h1>
                        </div>
                    </div>
                    <div class="social-links">

                        <div class="fb-icons">
                            <div class="fb-two"><a target="_blank" href="https://www.facebook.com/sharer.php?u=<?= get_permalink()?>"><i class="fa fa-facebook"></i></a></div>

                        </div>
                        <div class="twitter-icons aw-hide">
                            <div> <a target="_blank" href="https://twitter.com/share?url=<?= get_permalink()?>"><i class="fa fa-twitter"></i></a></div>
                        </div>

                        <div class="linkedin-icons aw-hide" >
                            <div><a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&url=<?= get_permalink()?>"><i class="fa fa-linkedin"></i></a></div>
                            
                        </div>
                        <div class="Close-icon">
                            <div><a href="javascript:" class="close" onclick="jQuery(this).hide();jQuery('.open').show();jQuery('.aw-hide').hide();"><i class="fa fa-times-circle"></i></a>
                            <a href="javascript:" class="open" onclick="jQuery(this).hide();jQuery('.close').show();jQuery('.aw-hide').show();"><i class="fa fa-ellipsis-h"></i></a>
                            
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-2">
                <div class="heading-text">
<h1>
    
    
    <?= the_title();?>
    
</h1>
                </div>

                <!--<div class="date">-->
                <!--    <p><?php //get_field('document_date')?></p>-->
                <!--</div>-->

                <div class="col-content">
                    <div class="pgraphs">
                        
                        <h6>วันที่เอกสาร </h6>
                        <p><?= get_field('document_date')?></p>
                    </div>
                    <div class="pgrphs">
                        <h6>เลขที่หนังสือ</h6>
                        <p><?= get_field('file_no')?></p>
                    </div>
                    <div class="pgrphs">
                        <h6>เลขตู้</h6>
                        <p><?= get_field('folder_no')?></p>
                    </div>
                    <div class="pgrphs">
                        <h6>ข้อกฎหมาย</h6>
                        <p><?= get_field('law_code')?>กร</p>
                    </div>
                    
                    <div class="pgrphs">
                        <h6>ข้อหารือ</h6>
                        <p style="white-space: pre-wrap;"><?= get_field('question')?></p>
                    </div>
                    <div class="pgrphs">
                        <h6>แนววินิจฉัย</h6>
                        <p style="white-space: pre-wrap;"><?= get_field('answer')?></p>
                    </div>
                    
                    <div class="pgrphs">
                        <h6>กรมสรรพากรแก้ไขล่าสุด</h6>
                        <p><?= get_field('last_update_date')?></p>
                    </div>

                </div>

                <div class="btn-sec">
                    <a target="_blank" href="https://www.facebook.com/sharer.php?u=<?= get_permalink()?>" class="btn-fb"><i class="fa fa-facebook"></i>&nbsp; แชร์บนเฟสบุ๊ค
                    </a>
                </div>

            </div>

        </div>

    </div>


<script>
jQuery(document).ready(function(){
	jQuery(".aw-hide").hide();
	jQuery(".close").hide();
});
</script>


<?php

get_footer();