<?php

/**
 * Fired during plugin activation
 *
 * @link       http://abdulwahab.ml
 * @since      1.0.0
 *
 * @package    Wp_Discussion
 * @subpackage Wp_Discussion/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wp_Discussion
 * @subpackage Wp_Discussion/includes
 * @author     Abdul Wahab <websolutionofficial@gmail.com>
 */
class Wp_Discussion_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
