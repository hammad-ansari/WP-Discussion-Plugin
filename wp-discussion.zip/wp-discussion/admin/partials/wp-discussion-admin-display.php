<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://abdulwahab.ml
 * @since      1.0.0
 *
 * @package    Wp_Discussion
 * @subpackage Wp_Discussion/admin/partials
 */
 
 echo "<br><br>";
 
  global $wpdb;
 
 if(isset($_POST['submit'])){
     
        $row = 1;
$filename = $_FILES['file']['tmp_name'];
    $handle = fopen($filename, "r");
  
    while (($data = fgetcsv($handle,",")) != FALSE) {

if($row++ == 1){
    continue;
}


$file_no = $data[0];

$slug = $data[1];
$folder_no = $data[2];
$law_code = $data[3];
$title = $data[4];
$question = $data[5];
$answer = $data[6];
$date = $data[7];
$last_update = $data[8];
$action = $data[9];

echo $action == 'create';   

switch($action){
    
    case 'create':
        
        $post_slug = str_replace(' ','',$file_no);
        $post_slug = str_replace('/','-',$post_slug);
        $post_slug = str_replace('.','',$post_slug);
        
        $post = get_page_by_path($post_slug, OBJECT, 'discussion' );
    
        if(!$post){
        
            // if($slug == 'auto')
            //     $id = wp_insert_post(['post_title' => $title,'post_content' => '','post_type' => 'discussion','post_status' => 'publish']);
            // else
                $id = wp_insert_post(['post_title' => $title,'post_name' => $post_slug,'post_content' => '','post_type' => 'discussion','post_status' => 'publish']);
                
                if($id){
                update_field('document_date',$date,$id);
                update_field('file_no',$file_no,$id);
                update_field('folder_no',$folder_no,$id);
                update_field('law_code',$law_code,$id);
                update_field('question',$question,$id);
                update_field('answer',$answer,$id);
                update_field('last_update_date',$last_update,$id);
                
                echo "{$file_no} Discussion Created<br>";
                
                }else{
                    echo "Failed to create {$file_no} Discussion<br>";
                }
                
        }else{
            
             echo "{$file_no} Discussion already exist!<br>";
            
        }
        
        break;
        
    case 'edit':
        
        $post_slug = str_replace(' ','',$file_no);
        $post_slug = str_replace('/','-',$post_slug);
        $post_slug = str_replace('.','',$post_slug);
    
    $post = get_page_by_path($post_slug, OBJECT, 'discussion' );
    
    if($post){
        
        wp_update_post(['post_title' => $title,'ID'=>$post->ID]);
        
            update_field('document_date',$date,$post->ID);
            update_field('folder_no',$folder_no,$post->ID);
            update_field('law_code',$law_code,$post->ID);
            update_field('question',$question,$post->ID);
            update_field('answer',$answer,$post->ID);
            update_field('last_update_date',$last_update,$post->ID);
        
        echo "{$file_no} Discussion Updated<br>";
    }else{
        echo "Failed to update {$file_no} Discussion<br>";
    }
        
        break;
        
    case 'delete':
        
        $post_slug = str_replace(' ','',$file_no);
        $post_slug = str_replace('/','-',$post_slug);
        $post_slug = str_replace('.','',$post_slug);
    
    $post = get_page_by_path($post_slug, OBJECT, 'discussion' );
    
    if($post){
        wp_delete_post($post->ID);
         echo "{$file_no} Discussion Deleted<br>";
    }else{
        echo "Failed to delete {$file_no} Discussion<br>";
    }
    
        break;
    
}



}
     
 }
 
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<br>
<br>


<form method="post" action="" enctype="multipart/form-data">
    
    <input type="file" name="file" required/><br>
    <input type="submit" name="submit" value="Read"/>
    
</form>