<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://abdulwahab.ml
 * @since      1.0.0
 *
 * @package    Wp_Discussion
 * @subpackage Wp_Discussion/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wp_Discussion
 * @subpackage Wp_Discussion/admin
 * @author     Abdul Wahab <websolutionofficial@gmail.com>
 */
class Wp_Discussion_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wp_Discussion_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wp_Discussion_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wp-discussion-admin.css', array(), $this->version, 'all' );
		
		if(isset($_GET['post_type']) && $_GET['post_type'] == 'discussion'){
		    
		    echo "<style>
		    
		    #filter-by-date,#post-query-submit{
		        display:none;
		    }
		        
		    </style>";
		    
		}

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wp_Discussion_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wp_Discussion_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wp-discussion-admin.js', array( 'jquery' ), $this->version, false );
		
		wp_localize_script($this->plugin_name,'localize',array('url' => admin_url('admin.php?page=aw-import')));

	}
	
	public function aw_discussion_column_html($column, $post_id){
	    
	    switch ( $column ) {

    		case 'file_no' :
    		$checkin = get_field('file_no',$post_id);
    
    		echo $checkin;
    
    
    		break; 
    
    		case 'folder_no' :
    
    		$checkout = get_field('folder_no',$post_id);
    
    		echo $checkout;
    
    		break;
    		
    		case 'document_date' :
    
    		$checkout = get_field('document_date',$post_id);
    
    		echo $checkout;
    
    		break;
    		
    		case 'title':
    		    
    		    echo substr(get_the_title($post_id),10);
    		    
    		    break;


	    }
	    
	}
	
	public function aw_discussion_column($columns){
	    
	    $new = array();

	foreach($columns as $key=>$value) {

		if($key=='date') {  

			$new['file_no'] = __( 'เลขที่หนังสือ', 'your_text_domain' ); 
			$new['folder_no'] = __( 'เลขตู้', 'your_text_domain' ); 
			$new['document_date'] = __( 'วันที่', 'your_text_domain' );  

		}else{
		    
		    $new[$key]=$value;
		    
		}
		
// 		if($key == 'title')
// 		    $new[$key]='';
		
	}
	


	return $new;
	    
	}
	
	
	public function acf_save_post_hook($post_id){
	    
	    if ( ! wp_is_post_revision( $post_id ) && get_field('file_no',$post_id) ) {
	        
	        $post_slug = str_replace(' ','',get_field('file_no',$post_id));
            $post_slug = str_replace('/','-',$post_slug);
            $post_slug = str_replace('.','',$post_slug);
	    
    	    remove_action( 'acf/save_post', array($this,'acf_save_post_hook') );
    	    
    	    wp_update_post( array(
                'ID' => $post_id,
                'post_name' =>  $post_slug// do your thing here
            ));
    
            // re-hook this function
            add_action( 'acf/save_post', array($this,'acf_save_post_hook') );
            
	    }
	    
	}
	
	
	public function discussion_cpt(){
		register_post_type( 'discussion',
	    // CPT Options
	        array(
	            'labels' => array(
	                'name' => __( 'Discussions' ),
	                'singular_name' => __( 'Discussion' )
	            ),
	            'public' => true,
	            'has_archive' => true,
	            'show_in_rest' => true,
	            'supports' => array('title','slug')
	 
	        )
	    );
	    
	   
    add_submenu_page(
        'edit.php?post_type=discussion',
        __( 'Import', 'textdomain' ),
        __( 'Import', 'textdomain' ),
        'manage_options',
        'aw-import',
        array($this,'books_ref_page_callback')
    );
	    
	    
	    if( function_exists('acf_add_local_field_group') ):

acf_add_local_field_group(array(
	'key' => 'group_5f323d13d2fe1',
	'title' => 'Discussion Custom Fields',
	'fields' => array(
		array(
			'key' => 'field_5f323d3f1b780',
			'label' => 'วันที่',
			'name' => 'document_date',
			'type' => 'text',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			)
		),
		array(
			'key' => 'field_5f323d9f1b781',
			'label' => 'เลขที่หนังสือ',
			'name' => 'file_no',
			'type' => 'text',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'default_value' => '',
			'placeholder' => '',
			'prepend' => '',
			'append' => '',
			'maxlength' => '',
		),
		array(
			'key' => 'field_5f323db31b782',
			'label' => 'เลขตู้',
			'name' => 'folder_no',
			'type' => 'text',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'default_value' => '',
			'placeholder' => '',
			'prepend' => '',
			'append' => '',
			'maxlength' => '',
		),
		array(
			'key' => 'field_5f323dc11b783',
			'label' => 'ข้อกฎหมาย',
			'name' => 'law_code',
			'type' => 'text',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'default_value' => '',
			'placeholder' => '',
			'prepend' => '',
			'append' => '',
			'maxlength' => '',
		),
		array(
			'key' => 'field_5f323dd71b784',
			'label' => 'ข้อหารือ',
			'name' => 'question',
			'type' => 'textarea',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'default_value' => '',
			'placeholder' => '',
			'prepend' => '',
			'append' => '',
			'maxlength' => '',
		),
		array(
			'key' => 'field_5f323de21b785',
			'label' => 'แนววินิจฉัย',
			'name' => 'answer',
			'type' => 'textarea',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'default_value' => '',
			'placeholder' => '',
			'prepend' => '',
			'append' => '',
			'maxlength' => '',
		),
		array(
			'key' => 'field_5f323dec1b786',
			'label' => 'วันที่เปลี่ยนแปลงล่าสุด  ',
			'name' => 'last_update_date',
			'type' => 'text',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			)
		),
	),
	'location' => array(
		array(
			array(
				'param' => 'post_type',
				'operator' => '==',
				'value' => 'discussion',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'normal',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => '',
	'active' => true,
	'description' => '',
));

endif;
	    
	}
	
	public function books_ref_page_callback(){
	    
	   include "partials/wp-discussion-admin-display.php";
	    
	}

}